-- ============================================================
-- uxcommunity — seed data
-- Run after schema.sql to populate master-data tables.
-- ============================================================

-- ─── Industry Sectors ───────────────────────────────────────
insert into design_sectors (name) values
  ('Healthcare & MedTech'),
  ('Finance & Fintech'),
  ('Industrial & Manufacturing'),
  ('Artificial Intelligence & ML'),
  ('E-commerce & Retail'),
  ('Education & EdTech'),
  ('Real Estate & PropTech'),
  ('Travel & Hospitality'),
  ('Media & Entertainment'),
  ('Food & Agritech'),
  ('Logistics & Supply Chain'),
  ('Automotive & Mobility'),
  ('Cybersecurity'),
  ('SaaS & Enterprise Software'),
  ('Government & Public Sector'),
  ('Gaming & Esports'),
  ('CleanTech & Sustainability'),
  ('Telecom & Networking'),
  ('Non-profit & Social Impact'),
  ('Other')
on conflict (name) do nothing;

-- ─── Indian Cities ──────────────────────────────────────────
insert into cities (name) values
  ('Mumbai'),
  ('Delhi'),
  ('Bengaluru'),
  ('Hyderabad'),
  ('Chennai'),
  ('Pune'),
  ('Kolkata'),
  ('Ahmedabad'),
  ('Jaipur'),
  ('Surat'),
  ('Lucknow'),
  ('Kanpur'),
  ('Nagpur'),
  ('Indore'),
  ('Thane'),
  ('Bhopal'),
  ('Visakhapatnam'),
  ('Patna'),
  ('Vadodara'),
  ('Ludhiana'),
  ('Agra'),
  ('Nashik'),
  ('Faridabad'),
  ('Meerut'),
  ('Rajkot'),
  ('Aurangabad'),
  ('Amritsar'),
  ('Navi Mumbai'),
  ('Prayagraj'),
  ('Ranchi'),
  ('Howrah'),
  ('Coimbatore'),
  ('Jabalpur'),
  ('Gwalior'),
  ('Vijayawada'),
  ('Jodhpur'),
  ('Madurai'),
  ('Raipur'),
  ('Kota'),
  ('Guwahati'),
  ('Chandigarh'),
  ('Thiruvananthapuram'),
  ('Mysuru'),
  ('Noida'),
  ('Gurugram'),
  ('Srinagar'),
  ('Mangaluru'),
  ('Kochi'),
  ('Bhubaneswar'),
  ('Dehradun')
on conflict (name) do nothing;

-- ─── Tags ───────────────────────────────────────────────────
insert into tags (name) values
  ('Top Talent'),
  ('Strong Portfolio'),
  ('UI Expert'),
  ('UX Expert'),
  ('Product Designer'),
  ('Design Systems'),
  ('Motion'),
  ('Junior'),
  ('Mid-Level'),
  ('Senior'),
  ('Needs Review'),
  ('High Priority'),
  ('Referral')
on conflict (name) do nothing;
